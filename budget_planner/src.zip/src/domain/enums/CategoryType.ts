export enum CategoryType {
    Expense = 'expense',
    Income = 'income',
}